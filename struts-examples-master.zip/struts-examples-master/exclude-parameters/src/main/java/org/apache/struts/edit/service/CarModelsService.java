/**
 * 
 */
package org.apache.struts.edit.service;

/**
 * Specifies what methods a CarModelService
 * class must implement to provide information
 * about car models.
 * @author bphillips
 *
 */
public interface CarModelsService {
	
	
	String [] getCarModels() ;

}
