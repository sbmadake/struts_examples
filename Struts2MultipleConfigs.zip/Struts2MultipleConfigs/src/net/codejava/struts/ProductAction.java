package net.codejava.struts;

import com.opensymphony.xwork2.ActionSupport;

public class ProductAction extends ActionSupport {
	public String execute() {
		System.out.println("hit ProductAction!");
		return SUCCESS;
	}
}
