package net.codejava.struts;

import com.opensymphony.xwork2.ActionSupport;

public class ComputerAction extends ActionSupport {
	public String execute() {
		System.out.println("hit ComputerAction!");
		return SUCCESS;
	}
}
