package net.codejava.struts;

import com.opensymphony.xwork2.ActionSupport;

public class UserAction extends ActionSupport {
	public String execute() {
		System.out.println("hit UserAction!");
		return SUCCESS;
	}
}
