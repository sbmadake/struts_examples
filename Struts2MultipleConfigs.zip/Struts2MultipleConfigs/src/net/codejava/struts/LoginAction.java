package net.codejava.struts;

import com.opensymphony.xwork2.ActionSupport;

public class LoginAction extends ActionSupport {
	public String execute() {
		System.out.println("hit LoginAction!");
		return SUCCESS;
	}
}
