package net.codejava.struts;

import com.opensymphony.xwork2.ActionSupport;

public class AdminAction extends ActionSupport {
	public String execute() {
		System.out.println("hit AdminAction!");
		return SUCCESS;
	}
}
