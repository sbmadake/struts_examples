/*
 * Copyright 2004-2005 The Apache Software Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hdiv.taglib.html;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.StringTokenizer;

import javax.servlet.jsp.PageContext;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.apache.cactus.JspTestCase;
import org.apache.struts.Globals;
import org.hdiv.taglib.SimpleBeanForTesting;

/**
 * Suite of unit tests for the <code>org.hdiv.taglib.html.LinkTagHDIV</code> class.
 */
public class LinkTag7Test extends JspTestCase {

	/**
	 * Defines the testcase name for JUnit.
	 * 
	 * @param theName the testcase's name.
	 */
	public LinkTag7Test(String theName) {
		super(theName);
	}

	/**
	 * Start the tests.
	 * 
	 * @param theArgs the arguments. Not used
	 */
	public static void main(String[] theArgs) {
		junit.awtui.TestRunner.main(new String[] { LinkTag7Test.class.getName() });
	}

	/**
	 * @return a test suite (<code>TestSuite</code>) that includes all methods
	 *         starting with "test"
	 */
	public static Test suite() {
		// All methods starting with "test" will be executed in the test suite.
		return new TestSuite(LinkTag7Test.class);
	}

	private void runMyTest(String whichTest, String locale) {

		pageContext.setAttribute(Globals.LOCALE_KEY, new Locale(locale, locale),
									PageContext.SESSION_SCOPE);
		request.setAttribute("runTest", whichTest);
		try {
			pageContext.forward("/test/org/hdiv/taglib/html/TestLinkTag7.jsp");
		} catch (Exception e) {
			e.printStackTrace();
			fail("There is a problem that is preventing the tests to continue!");
		}
	}

	/*
	 * Testing LinkTagHDIV.
	 */

	public void testLinkPage() {
		runMyTest("testLinkPage", "");
	}

	public void testLinkPageAccesskey() {
		runMyTest("testLinkPageAccesskey", "");
	}

	public void testLinkPageAnchor() {
		runMyTest("testLinkPageAnchor", "");
	}

	public void testLinkPageIndexedArray() {
		ArrayList lst = new ArrayList();
		lst.add("Test Message");
		pageContext.setAttribute("lst", lst, PageContext.REQUEST_SCOPE);
		runMyTest("testLinkPageIndexedArray", "");
	}

	public void testLinkPageIndexedArrayProperty() {
		SimpleBeanForTesting sbft = new SimpleBeanForTesting();
		ArrayList lst = new ArrayList();
		lst.add("Test Message");
		sbft.setList(lst);
		pageContext.setAttribute("lst", sbft, PageContext.REQUEST_SCOPE);
		runMyTest("testLinkPageIndexedArrayProperty", "");
	}

	public void testLinkPageIndexedMap() {
		HashMap map = new HashMap();
		map.put("tst1", "Test Message");
		pageContext.setAttribute("lst", map, PageContext.REQUEST_SCOPE);
		runMyTest("testLinkPageIndexedMap", "");
	}

	public void testLinkPageIndexedMapProperty() {
		SimpleBeanForTesting sbft = new SimpleBeanForTesting();
		HashMap map = new HashMap();
		map.put("tst1", "Test Message");
		sbft.setMap(map);
		pageContext.setAttribute("lst", sbft, PageContext.REQUEST_SCOPE);
		runMyTest("testLinkPageIndexedMapProperty", "");
	}

	public void testLinkPageIndexedEnumeration() {
		StringTokenizer st = new StringTokenizer("Test Message");
		pageContext.setAttribute("lst", st, PageContext.REQUEST_SCOPE);
		runMyTest("testLinkPageIndexedEnumeration", "");
	}

	public void testLinkPageIndexedEnumerationProperty() {
		SimpleBeanForTesting sbft = new SimpleBeanForTesting();
		StringTokenizer st = new StringTokenizer("Test Message");
		sbft.setEnumeration(st);
		pageContext.setAttribute("lst", sbft, PageContext.REQUEST_SCOPE);
		runMyTest("testLinkPageIndexedEnumerationProperty", "");
	}

	public void testLinkPageIndexedAlternateIdArray() {
		ArrayList lst = new ArrayList();
		lst.add("Test Message");
		pageContext.setAttribute("lst", lst, PageContext.REQUEST_SCOPE);
		runMyTest("testLinkPageIndexedAlternateIdArray", "");
	}

	public void testLinkPageIndexedAlternateIdArrayProperty() {
		SimpleBeanForTesting sbft = new SimpleBeanForTesting();
		ArrayList lst = new ArrayList();
		lst.add("Test Message");
		sbft.setList(lst);
		pageContext.setAttribute("lst", sbft, PageContext.REQUEST_SCOPE);
		runMyTest("testLinkPageIndexedAlternateIdArrayProperty", "");
	}

	public void testLinkPageIndexedAlternateIdMap() {
		HashMap map = new HashMap();
		map.put("tst1", "Test Message");
		pageContext.setAttribute("lst", map, PageContext.REQUEST_SCOPE);
		runMyTest("testLinkPageIndexedAlternateIdMap", "");
	}

	public void testLinkPageIndexedAlternateIdMapProperty() {
		SimpleBeanForTesting sbft = new SimpleBeanForTesting();
		HashMap map = new HashMap();
		map.put("tst1", "Test Message");
		sbft.setMap(map);
		pageContext.setAttribute("lst", sbft, PageContext.REQUEST_SCOPE);
		runMyTest("testLinkPageIndexedAlternateIdMapProperty", "");
	}

	public void testLinkPageIndexedAlternateIdEnumeration() {
		StringTokenizer st = new StringTokenizer("Test Message");
		pageContext.setAttribute("lst", st, PageContext.REQUEST_SCOPE);
		runMyTest("testLinkPageIndexedAlternateIdEnumeration", "");
	}

	public void testLinkPageIndexedAlternateIdEnumerationProperty() {
		SimpleBeanForTesting sbft = new SimpleBeanForTesting();
		StringTokenizer st = new StringTokenizer("Test Message");
		sbft.setEnumeration(st);
		pageContext.setAttribute("lst", sbft, PageContext.REQUEST_SCOPE);
		runMyTest("testLinkPageIndexedAlternateIdEnumerationProperty", "");
	}

	public void testLinkPageLinkName() {
		runMyTest("testLinkPageLinkName", "");
	}

	public void testLinkPageNameNoScope() {
		HashMap map = new HashMap();
		map.put("param1", "value1");
		map.put("param2", "value2");
		map.put("param3", "value3");
		map.put("param4", "value4");
		pageContext.setAttribute("paramMap", map, PageContext.REQUEST_SCOPE);
		runMyTest("testLinkPageNameNoScope", "");
	}

	public void testLinkPageNamePropertyNoScope() {
		HashMap map = new HashMap();
		map.put("param1", "value1");
		map.put("param2", "value2");
		map.put("param3", "value3");
		map.put("param4", "value4");
		SimpleBeanForTesting sbft = new SimpleBeanForTesting(map);
		pageContext.setAttribute("paramPropertyMap", sbft, PageContext.REQUEST_SCOPE);
		runMyTest("testLinkPageNamePropertyNoScope", "");
	}

	public void testLinkPageNameApplicationScope() {
		HashMap map = new HashMap();
		map.put("param1", "value1");
		map.put("param2", "value2");
		map.put("param3", "value3");
		map.put("param4", "value4");
		pageContext.setAttribute("paramMap", map, PageContext.APPLICATION_SCOPE);
		runMyTest("testLinkPageNameApplicationScope", "");
	}

	public void testLinkPageNamePropertyApplicationScope() {
		HashMap map = new HashMap();
		map.put("param1", "value1");
		map.put("param2", "value2");
		map.put("param3", "value3");
		map.put("param4", "value4");
		SimpleBeanForTesting sbft = new SimpleBeanForTesting(map);
		pageContext.setAttribute("paramPropertyMap", sbft, PageContext.APPLICATION_SCOPE);
		runMyTest("testLinkPageNamePropertyApplicationScope", "");
	}

	public void testLinkPageNameSessionScope() {
		HashMap map = new HashMap();
		map.put("param1", "value1");
		map.put("param2", "value2");
		map.put("param3", "value3");
		map.put("param4", "value4");
		pageContext.setAttribute("paramMap", map, PageContext.SESSION_SCOPE);
		runMyTest("testLinkPageNameSessionScope", "");
	}

	public void testLinkPageNamePropertySessionScope() {
		HashMap map = new HashMap();
		map.put("param1", "value1");
		map.put("param2", "value2");
		map.put("param3", "value3");
		map.put("param4", "value4");
		SimpleBeanForTesting sbft = new SimpleBeanForTesting(map);
		pageContext.setAttribute("paramPropertyMap", sbft, PageContext.SESSION_SCOPE);
		runMyTest("testLinkPageNamePropertySessionScope", "");
	}

	public void testLinkPageNameRequestScope() {
		HashMap map = new HashMap();
		map.put("param1", "value1");
		map.put("param2", "value2");
		map.put("param3", "value3");
		map.put("param4", "value4");
		pageContext.setAttribute("paramMap", map, PageContext.REQUEST_SCOPE);
		runMyTest("testLinkPageNameRequestScope", "");
	}

	public void testLinkPageNamePropertyRequestScope() {
		HashMap map = new HashMap();
		map.put("param1", "value1");
		map.put("param2", "value2");
		map.put("param3", "value3");
		map.put("param4", "value4");
		SimpleBeanForTesting sbft = new SimpleBeanForTesting(map);
		pageContext.setAttribute("paramPropertyMap", sbft, PageContext.REQUEST_SCOPE);
		runMyTest("testLinkPageNamePropertyRequestScope", "");
	}

}
