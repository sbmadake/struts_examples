package org.apache.struts.webapp.examples.attacks.dao;

import java.util.List;

public interface IAccountDao {
	List getUserAccount(String paramString);
}