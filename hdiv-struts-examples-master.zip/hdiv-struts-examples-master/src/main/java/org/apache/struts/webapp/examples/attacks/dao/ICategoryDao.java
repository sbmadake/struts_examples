package org.apache.struts.webapp.examples.attacks.dao;

import java.util.List;

public interface ICategoryDao {
	List getCategoryList();
}