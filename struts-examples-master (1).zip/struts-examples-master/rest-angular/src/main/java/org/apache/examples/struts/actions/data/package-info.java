@ParentPackage("data")
@Namespace("/data")
package org.apache.examples.struts.actions.data;

import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;