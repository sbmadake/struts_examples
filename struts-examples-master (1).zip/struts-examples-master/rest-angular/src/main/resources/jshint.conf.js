{
    "maxparams": 5,
    "indent": true,
    "camelcase": true,
    "eqeqeq": true,
    "forin": true,
    "immed": true,
    "latedef": false,
    "noarg": true,
    "noempty": true,
    "nonew": true,
    "globals": {}
}