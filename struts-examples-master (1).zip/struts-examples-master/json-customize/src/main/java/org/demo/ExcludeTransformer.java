package org.demo;

import flexjson.transformer.AbstractTransformer;

public class ExcludeTransformer extends AbstractTransformer {
    public void transform(Object o) {
        return;
    }
}
